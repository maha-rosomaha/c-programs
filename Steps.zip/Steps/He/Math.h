#ifndef Math_c
#define Math_c value

void
make_abort(int w);
void
end_with_error(int err_num);

#endif
