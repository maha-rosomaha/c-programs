#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/types.h>

enum {
    PAC_SIZE = 5,
    N_SIZE = 3,
    BIG_SIZE = 500,
    OPINION = 2,
    ANSW_SIZE = 10,
    RESULT_SIZE = 13,
};

static int
stop_msg(int *);

static void
make_exit(int b)
{
    if (b == -1) {
/*        stop_msg(input);
        wait(NULL);*/
        exit(1);
    }
}

static void
end_with_errno(int err)
{
    char *msg = strerror(err);
    int w = write(2, msg, strlen(msg));
    make_exit(w);
/*    stop_msg(input);
    wait(NULL);*/
    exit(1);
}

static void
end_with_err(int w, int err)
{
    if (w == -1) {
        char *msg = strerror(err);
        int w = write(2, msg, strlen(msg));
        make_exit(w);
/*        stop_msg(input);
        wait(NULL);*/
        exit(1);
    }
}

static int
stop_msg(int *input) 
{
    char msg[PAC_SIZE];
    memset(msg, 0, PAC_SIZE);
    memcpy(msg, "stop\n", 5);
    int w = write(input[1], msg, PAC_SIZE);
    end_with_err(w, errno);
    return 0;
}

static char *
msg_from_test(int *output, char *msg)
{
    int i, quan, r, w;
    char num_b[N_SIZE];
    char str_pacs[PAC_SIZE];
    memset(num_b, 0, N_SIZE);
    memset(str_pacs, 0, PAC_SIZE);
    //получаем первые символы сообщения - количество пакетов
    r = read(output[0], num_b, N_SIZE);
    end_with_err(r, errno);
    quan = strtol(num_b, NULL, 10);
    //считываем остаток сообщения - quan пакетов 
    for (i = 0; i < quan; i++) {
        //последний пакет может быть заполнен не полностью + там могут быть номера вопросов, если идет их считывание 
        if (i == quan - 1) {
            memset(str_pacs, 0, PAC_SIZE);
            r = read(output[0], str_pacs, PAC_SIZE);
            end_with_err(r, errno);
            w = write(1, str_pacs, PAC_SIZE);
            end_with_err(w, errno);
            //если тут будет число (единственный случай, когда используется возвращаемое згначение), то его длина < длины пакета
            str_pacs[PAC_SIZE - 1] = '\0';
            memcpy(msg, str_pacs, PAC_SIZE);
            return msg;
        } else {
            memset(str_pacs, 0, PAC_SIZE);
            r = read(output[0], str_pacs, PAC_SIZE);
            end_with_err(r, errno);
            w = write(1, str_pacs, PAC_SIZE);
            end_with_err(w, errno);
        }
    }
    return msg;
}

static void
theme_master(int *input, int *output) {
    int w = 0;
    char buf_for_msgs[PAC_SIZE];        //BIGSIZE
    char buf_for_numb[PAC_SIZE];
    //пересылка команды gett в тест
    memset(buf_for_msgs, 0, PAC_SIZE);
    memcpy(buf_for_msgs, "gett\n", PAC_SIZE);
    w = write(input[1], buf_for_msgs, PAC_SIZE);
    end_with_err(w, errno);
    //получение сообщения из теста для записи ее на экран
    msg_from_test(output, buf_for_numb);
    return;
}

static int
more_info(int *input, int *output)
{
    int w = 0;
    int r = 0;
    char buf_for_msgs[PAC_SIZE];
    char buf_for_numb[PAC_SIZE];
    char *info = "Would you like to see more information about this test and get acces for it? (Y/y for yes) ";
    char decision[OPINION];
    w = write(1, info, strlen(info));
    end_with_err(w, errno);
    r = read(0, decision, OPINION);
    end_with_err(r, errno);
    if (memcmp(decision, "Y\n", OPINION) != 0 && memcmp(decision, "y\n", OPINION) != 0) {
        return -1;
    } else {
        int quan = 0;
        char *text_number = "The quantity of questions in this theme is: ";
        w = write(1, text_number, strlen(text_number));
        end_with_err(w, errno);
        memset(buf_for_msgs, 0, PAC_SIZE);
        memcpy(buf_for_msgs, "getn\n", PAC_SIZE);
        w = write(input[1], buf_for_msgs, PAC_SIZE);
        msg_from_test(output, buf_for_numb);
        putchar('\n');
        quan = strtol(buf_for_numb, NULL, 10);
        if (quan < 0) {
            char *error = "Something gone wrong\n"; 
            w = write(2, error, strlen(error));
            end_with_err(w, errno);
            exit(1);
        } else {
            return quan;
        }
    }
}

static int
cmp_answer(int *input, int *output)
{
    int w = 0;
    const char *right = "Good\n";
    const char *wrong = "Bad\n";
    const char *write_answer = "Write answer: ";
    char buf_for_msgs[PAC_SIZE];
    char buf_for_result[RESULT_SIZE];
    char answ[ANSW_SIZE];
    memset(buf_for_msgs, 0, PAC_SIZE);
    memcpy(buf_for_msgs, "cmpa\n", 5);
    w = write(input[1], buf_for_msgs, PAC_SIZE);
    end_with_err(w, errno);
    w = write(1, write_answer, strlen(write_answer));
    end_with_err(w, errno);
    printf("\nLOOL\n");
    //считываем ответ
    memset(answ, 0, ANSW_SIZE);
    if (fgets(answ, ANSW_SIZE, stdin) == NULL){
        end_with_errno(errno);
        return -1;
    } else {
        int length = strlen(answ);
        if (answ[length - 1] != '\n') {
            char c = '0';
            while (c != '\n') {
                c = getchar();
            }
            w = write(1, wrong, strlen(wrong));
            end_with_err(w, errno);
            return -1;
        } else {
            w = write(input[1], answ, strlen(answ));
            end_with_err(w, errno);
        }
        memset(buf_for_result, 0, PAC_SIZE);
        msg_from_test(output, buf_for_result);
        w = write(1, buf_for_msgs, strlen(buf_for_msgs));
        end_with_err(w, errno);
        if (memcmp(buf_for_result, right, PAC_SIZE) != 0) {
            return 0;
        } else {
            return 1;
        } 
    }
}

static int
testing(int *input, int *output, int quan)
{
    int w = 0;
    int i = 0;
    int result = 0;
    int loc_res = 0;
    char buf_for_msgs[BIG_SIZE];
    char buf_for_numb[PAC_SIZE];
    for (i = 0; i < quan; i++) {
        //посылаю комманду getq
        memset(buf_for_msgs, 0, PAC_SIZE);
        memcpy(buf_for_msgs, "getq\n", PAC_SIZE);
        w = write(input[1], buf_for_msgs, PAC_SIZE);
        end_with_err(w, errno);
        //посылаю номер вопроса
        memset(buf_for_msgs, 0, PAC_SIZE);
        sprintf(buf_for_msgs, "%d", i + 1);
        w = write(input[1], buf_for_msgs, PAC_SIZE);
        end_with_err(w, errno);
        //получаю овопрос
        msg_from_test(output, buf_for_numb);
        //сравниванию, что выдала мне функция сравнения ответов 
        if ((loc_res = cmp_answer(input, output)) == -1) {
            stop_msg(input);
            wait(NULL);
            exit(1);
        } else if (loc_res == 1) {
            result += 1;
        }
    }
    return result;
}

int
main(int argc, char **argv)
{
    if (argc != 2) {
        perror("Wrong number of arguements\n");
        exit(1);
    }
    int status = 0;
    int w = 0;
    int r = 0;
    int cur_pid = -1;
    int input[2], output[2];
    if (pipe(input) == -1) {
        end_with_errno(errno);
    }
    if (pipe(output) == -1) {
        end_with_errno(errno);
    }
    if ((cur_pid = fork()) == -1) {
    //ошибка форка
        end_with_errno(errno);
    }
    else if (cur_pid > 0) {
    //в отцовском процессе
        int quan_of_questions = 0;
        int result = 0;
        const char *empty = "You have passed empty test\n";
        const char *end_of_test = "The end of the testing\n";
        close(input[0]);
        close(output[1]);
        //узнаем тему
        theme_master(input, output);
        //спрашиваем, хотим ли узнать больше информации о тесте (обязательно, если хотим решить его)
        if ((quan_of_questions = more_info(input, output)) == -1) {
            //нет желания продолжать тест
            w = write(1, end_of_test, strlen(end_of_test));
            end_with_err(w, errno);
            stop_msg(input);
            wait(NULL);
            return 0;
        } else if (quan_of_questions == 0) {
            //пустой тест -> завершение
            w = write(1, empty, strlen(empty));
            end_with_err(w, errno);
            stop_msg(input);
            wait(NULL);
            return 0;
        } else {
            //узнаем, хотим ли решать его
            char *test_wish = "Would you like to start the test? (Y/y for yes) ";
            w = write(1, test_wish, strlen(test_wish));
            end_with_err(w, errno);
            char decision[OPINION];
            r = read(0, decision, OPINION);
            end_with_err(r, errno);
            if (memcmp(decision, "Y\n", OPINION) != 0 && memcmp(decision, "y\n", OPINION) != 0) {
                //не хотим решать -> завершение
                w = write(1, end_of_test, strlen(end_of_test));
                end_with_err(w, errno);
                stop_msg(input);
                wait(NULL);
                return 0;
            } else {
                int err = 0;
                result = testing(input, output, quan_of_questions);
                w = write(1, end_of_test, strlen(end_of_test));
                end_with_err(w, errno);
                printf("Your result is: %d/%d\n", result, quan_of_questions);
                stop_msg(input);
                err = wait(&status);
                if (err == -1) {
                    end_with_errno(errno);
                }
            }
        }
    } else {
        const char *ex_err = "EXEC ERROR\n";
        close(input[1]);
        close(output[0]);
        dup2(input[0], 0);
        dup2(output[1], 1);
        execl(argv[1], argv[1], NULL);
        w = write(2, ex_err, strlen(ex_err));
        end_with_err(w, errno);
        exit(1);
    }
}