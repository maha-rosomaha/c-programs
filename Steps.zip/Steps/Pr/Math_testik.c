#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <math.h>

enum {
//проверяю на правильность в программе - тестировщике
    MODESQ = 5,
    TEXTQ = 3,
    COM_SIZE = 5,
    ANSW_SIZE = 10,
    N_SIZE = 3,
    PAC_SIZE = 5,
};

static void
make_exit(int b)
{
    if (b == -1) {
        abort();
    }
}

static void
end_with_err(int r, int err)
{
    if (r == -1) {
        char *msg = strerror(err);
        int w = write(2, msg, strlen(msg));
        make_exit(w);
        exit(1);
    }
}

static int
communication(const char *str)
{
    int i, w, pacs_quan, len;
    char num_b[N_SIZE], str_pacs[PAC_SIZE];        //максимальная из возможных длин
    memset(num_b, 0, N_SIZE);
    memset(str_pacs, 0, PAC_SIZE);
    len = strlen(str);
    pacs_quan = ceil(((double)len)/PAC_SIZE);
    sprintf(num_b, "%d", pacs_quan);
    w = write(1, num_b, N_SIZE);
    end_with_err(w, errno);
    for (i = 0; i < pacs_quan; i++) {
        if (i == pacs_quan - 1) {
            memset(str_pacs, 0, PAC_SIZE);
            memcpy(str_pacs, str + i * PAC_SIZE, strlen(str) - i * PAC_SIZE);
            w = write(1, str_pacs, PAC_SIZE);
            end_with_err(w, errno);
        } else {
            memset(str_pacs, 0, PAC_SIZE);
            memcpy(str_pacs, str + i * PAC_SIZE, PAC_SIZE);
            w = write(1, str_pacs, PAC_SIZE);
            end_with_err(w, errno);
        }
    }
    return 0;
}

static int
choose_mode(const char *your_command, const char *mode[])
{
//прогоняем нашу команду и смотрим, есть ли такая. если есть - возвращаем ее номер в массиве команд
    int i, cur_mode = -1;
    for (i = 0; i < MODESQ; i++) {
        if (memcmp(your_command, mode[i], COM_SIZE) == 0) {
            cur_mode = i;
            break;
        }
    }
    if (cur_mode < 0) {
        const char *wrong_command = "There is no such a command\n";
        int w = write(2, wrong_command, strlen(wrong_command));
        end_with_err(w, errno);
        exit(1);
    }
    return cur_mode;
}

int
main(void)
{
    const char *theme = "This is Math test\n";
    const char *mas_of_questions[] = {"How much is 1 + 1?\n", "How much is 2 + 3?\n", "How many sides has the triangle?\n"};
    const char *mas_of_answers[] = {"2\n", "5\n", "3\n"};
    const char *mode[] = {"gett\n", "getq\n", "cmpa\n", "getn\n", "stop\n"};
    const char *right = "Good\n", *wrong = "Bad\n";
    int r = 0;
    int cur_mode = 0;
    char your_command[COM_SIZE];
    char number[COM_SIZE];
    char your_answer[ANSW_SIZE]; 
    memset(your_command, 0, COM_SIZE);
    while (1) {
        r = read(0, your_command, COM_SIZE);
        end_with_err(r, errno);
        //дальше идет выдача темы
        if ((cur_mode = choose_mode(your_command, mode)) == 0) {
        communication(theme);
    }
        //дальше идет выдача вопроса №...
        else if (cur_mode == 1) {
            memset(number, 0, COM_SIZE);
            r = read(0, number, COM_SIZE);
            end_with_err(r, errno);
            int quest_num = strtol(number, NULL, 10) - 1;
            communication(mas_of_questions[quest_num]);
        }
        //дальше идет сравнение ответа с вопросом №...
        else if (cur_mode == 2) {
        	memset(your_answer, 0, ANSW_SIZE);
        	r = read(0, your_answer, ANSW_SIZE);
        	end_with_err(r, errno);
        	int ans_num = strtol(your_answer, NULL, 10) - 1;

            memset(your_answer, 0, ANSW_SIZE);
            r = read(0, your_answer, ANSW_SIZE);

            if (memcmp(your_answer, mas_of_answers[ans_num], strlen(mas_of_answers[ans_num])) == 0) {
                communication(right);
            } else {
                communication(wrong);
            }
        }
        //дальше идет выдача количества вопросов
        else if (cur_mode == 3) {
            char str[N_SIZE];
            memset(str, 0, N_SIZE);
            sprintf(str, "%d", TEXTQ);
            communication(str);
        }
        //дальше идет завершение теста
        else if (cur_mode == 4) {
            break;
        }
    }		
    return 0;
}
