#!/bin/bash
rm *.out
rm -rf coverage
rm -rf lcov
rm *.txt
