#!/bin/bash
#git clone https://github.com/linux-test-project/lcov.git

gcc -g -o b.out ./Pr/Math_testik.c -I ./He/ -O2 -Wall -Werror -pedantic-errors -Wno-pointer-sign -Wextra -std=gnu11 -ftrapv -fsanitize=undefined -lm
echo "COMPILATION SUCCEEDED"
gcc -g ./Pr/Tester.c -I ./He/ -O2 -Wall -Werror -pedantic-errors -Wno-pointer-sign -Wextra -std=gnu11 -ftrapv -fsanitize=undefined
echo "COMPILATION SUCCEEDED"
./a.out 2> a.txt
