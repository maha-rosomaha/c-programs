#include <stdio.h>
#include <stdlib.h>
#define N 10

void
fill(int *A, int n) {
    int i = 0;
    while (i < n) {
        if (scanf("%d", &A[i]) != 1) {
		exit(1);
	}
        i += 1;
    }
}

int
change(int *A, int n) {
    int a, i = 0, k = 0;
    while (i < n) {
        if (A[i] >= 0 && A[i + 1] < 0 || A[i] > 0 && A[i + 1] <= 0) {
            a = A[i];
            A[i] = A[i + 1];
            A[i + 1] = a;
            k++;
        }
        i++;
    }
    return k;
}

void
on_screen(int *A, int n) {
    int i = 0;
    while(i < n) {
        printf("%d||", A[i]);
	i++;
    }
}

int
main(void) {
    int i = 1;
    int Mas[N];
    fill(Mas, N);
    while (i) {
        i = change(Mas, N);
    }
    on_screen(Mas, N);
    return 0;
}
