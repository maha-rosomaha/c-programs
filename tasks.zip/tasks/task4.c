#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define N 5

char **
create_read(int n) {
    char **A;
    int i, k = 0, newn, c;
    A = calloc(n, sizeof(char *));
    for (i = 0; i < n; i++) {
        newn = n;
        k = 0;
        A[i] = calloc(newn, sizeof(char));
        while ((c = getchar()) != '\n') {
            if (k >= newn) {
                newn *= 2;
                A[i] = realloc(A[i], newn);
            }
            A[i][k] = c;
            k++;
        }
        A[i] = realloc(A[i], k+1);
        A[i][k] = '\0';
    }
    return A;
}

void
on_screen(char **A, int n) {
    int i, j, k;
    for (i = 0; i < n; i++) {
        k = 0;
        while (A[i][k] != '\0') {
            k++;
        }
        for (j = 0; j < k; j++) {
            printf("%c", A[i][j]);
        }
        putchar('\n');
    }
}

void
print_last(char **A, int n) {
    int i, len;
    for (i = 0; i < n; i++) {
        len = strlen(A[i]);
        printf("%c\n", A[i][len - 1]);
    }
}

void
delete_mas(char **A, int n) {
    int i;
    for (i = 0; i < n; i++) {
        free(A[i]);
    }
    free(A);
}

int
main(void) {
    char **Mas;
    Mas = create_read(N);
    on_screen(Mas, N);
    print_last(Mas, N);
    delete_mas(Mas, N);
    return 0;
}
