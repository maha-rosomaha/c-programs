#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int
find_max(FILE *fp) {
    int start_pos, local_len = 0, max_len = 0, local_beg = 0, max_beg = 0, c;
    start_pos = ftell(fp);
    while ((c = fgetc(fp)) != EOF) {
        if (c != '\n') {
            while ((c = fgetc(fp)) != '\n') {
                if (c != EOF) {
                   local_len++;
                }
                else {
                    if (local_len > max_len) {
                        return local_beg;
                    }
                    else {
                        return max_beg;
                    }
                }
            }
        }
        local_len++;
        if (local_len > max_len) {
            max_len = local_len;
            max_beg = local_beg;
        }
        local_len = 0;
        local_beg = ftell(fp);
    }
    fseek(fp, start_pos, SEEK_SET);
    return max_beg;
}

void
print_max(FILE *fp, int beg_pos) {
    int start_pos, c;
    start_pos = ftell(fp);
    fseek(fp, beg_pos, SEEK_SET);
    c = fgetc(fp);
    while (c != EOF) {
        if (c == '\n') {
            putchar(c);
            break;
        }
        putchar(c);
        c = fgetc(fp);
    }
    fseek(fp, start_pos, SEEK_SET);
}

int
main(int argc, char *argv[]) {
    FILE *fp;
    int beg, c;
    if (argc < 2) {
        perror("NO FILE");
        exit(1);
    }
    fp = fopen(argv[argc - 1], "r");
    if (!fp) {
        perror("OPEN");
        exit(1);
    }
    beg = find_max(fp);
    print_max(fp, beg);
    fclose(fp);
    printf("***\n%d\n***\n", beg);
    return 0;
}
