#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct Node {
    int elem;
    struct Node *next;
} list;

list *
reading(list *lis, int n) {
    list *cur;
    cur = calloc(1, sizeof(list));
    cur->next = lis;
//    cur->elem = calloc(1, sizeof(int));
    cur->elem = n;
    return cur;
}

list *
add(void) {
    list *lis = NULL;
    int i, n, k;
    printf("how much?   ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        scanf("%d", &k);
        lis = reading(lis, k);
    }
    return lis;
}

list *
addition(list *lis, int n) {
    list *cur, *start = lis;
    cur = calloc(1, sizeof(list));
    cur->elem = n;
    if (!lis || lis->elem >= n) {
        cur->next = lis;
        return cur;
    }
    while (lis->next) {
        if (lis->next->elem >= n) {
            cur->next = lis->next;
            lis->next = cur;
            return start;
        }
        lis = lis->next;
    }
    cur->next = NULL;
    lis->next = cur;
    return start;
}


void
sort(list *lis) {
    list *tmp, *save = lis;
    int cur, nex, k = 1;
    if (!lis) {
        return;
    }
    while (k != 0) {
        k = 0;
        while (lis->next) {
            tmp = lis->next;
            cur = lis->elem;
            nex = tmp->elem;
            if (cur > nex) {
                lis->elem = nex;
                tmp->elem = cur;
                k++;
            }
            lis = lis->next;
        }
        lis = save;
    }
}


list *
create(list *lis1, list *lis2) {
    list *time_lis = NULL, *cur_new = NULL, *newlis = NULL, *lis3 = NULL;
    int fir, sec;
    while (lis1 && lis2) {
        fir = lis1->elem;
        sec = lis2->elem;
        newlis = calloc(1, sizeof(list));
        newlis->next = NULL;
        if (fir > sec) {
            newlis->elem = sec;
            lis2 = lis2->next;
        }
        else {
            newlis->elem = fir;
            lis1 = lis1->next;
        }
        if (!lis3) {
            lis3 = newlis;
            cur_new = newlis;
        }
        else {
            cur_new->next = newlis;
            cur_new = cur_new->next;
        }
    }

    if (lis1) {
        time_lis = lis1;
    } else {
        time_lis = lis2;
    }
    while (time_lis) {
        newlis = calloc(1, sizeof(list));
        newlis->elem = time_lis->elem;
        newlis->next = NULL;
        if (!lis3) {
            lis3 = newlis;
            cur_new = newlis;
        }
        else {
            cur_new->next = newlis;
            cur_new = cur_new->next;
        }
        time_lis = time_lis->next;
    }
    return lis3;
}

void
on_screen(list *lis) {
    while (lis) {
        printf("%d|=>", lis->elem);
        lis = lis->next;
    }
}

void
delete_mem(list *lis) {
    list *tmp;
    while (lis) {
        tmp = lis;
        lis = lis->next;
        free(tmp);
    }
}

int
main(void) {
    list *lis1 = NULL, *lis2 = NULL, *lis3 = NULL;

    lis1 = add();
    on_screen(lis1);
    putchar('\n');
//    sort(lis1);
  //  on_screen(lis1);
  //  putchar('\n');

    lis2 = add();
    on_screen(lis2);
    putchar('\n');
 //   sort(lis2);
   // on_screen(lis2);
 //   putchar('\n');

    lis3 = create(lis1, lis2);
    on_screen(lis3);
    putchar('\n');


/*    for (i = 0; i < 5; i++) {
        scanf("%d", &n);
        lis1 = addition(lis1, n);
        on_screen(lis1);
        putchar('\n');
    }
*/    delete_mem(lis1);
     delete_mem(lis2);
    delete_mem(lis3);
/*    list *li1 = NULL, *li2 = NULL, *li3 = NULL;
    printf("creating first list\n");
    li1 = add(li1);
    on_screen(li1);
    putchar('\n');
    printf("creating second list\n");
    li2 = add(li2);
    on_screen(li2);
    putchar('\n');
    sort(li1);
    sort(li2);
    on_screen(li1);
    putchar('\n');
    on_screen(li2);
    putchar('\n');
    li3 = create(li1, li2);
    on_screen(li3);
    delete_mem(li1);
    delete_mem(li2);
    delete_mem(li3);
*/    return 0;
}

