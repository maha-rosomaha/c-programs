#include <stdio.h>
#include <stdlib.h>

void
swap(int *a, int *b) {
    int c;
    c = *a;
    *a = *b;
    *b = c;
}

int *
mas_cr(int n) {
    int *A;
    A = calloc(n, sizeof(int));
    return A;
}

void
fill(int *A, int n) {
    int i;
    for (i = 0; i < n; i++) {
        scanf("%d", &A[i]);
    }
}

void
sort(int *A, int n) {
    int a, i, k = 1, l = n - 1;
    while (k != 0 && l >= 1) {
        k = 0;
        for (i = 0; i < l; i++) {
            if (A[i] > A[i+1]) {
                swap(&A[i], &A[i+1]);
                l--;
		k++;
            }
        }
    }
}


/*    int last = n - 1, left = 1, right = n - 1, j;
    do {
        for (j = right; j >= last; j--) {
            if (A[j - 1] > A[j]) {
                swap(&A[j - 1], &A[j]);
                last = j;
            }
        }
        for (j = left; j < right; j++) {
            if (A[j - 1] > A[j]) {
                swap(&A[j - 1], &A[j]);
                last = j;
            }
        }
        right = last - 1;
    } while (left < right);
*/

void
on_screen(int *A, int n) {
    int i;
    for (i = 0; i < n - 1; i++) {
        printf("%d||=>", A[i]);
    }
    printf("%d", A[n - 1]);
    putchar('\n');
}

void
delete_mas(int *A, int n) {
    int i;
   // for (i = 0; i < n; i++) {
        free(A);
//    }
}

int
main(void) {
    int *Mas, n;
    printf("How much? ");
    scanf("%d", &n);
    Mas = mas_cr(n);
    fill(Mas, n);
    on_screen(Mas, n);
    sort(Mas, n);
    on_screen(Mas, n);
    delete_mas(Mas, n);
    return 0;
}
