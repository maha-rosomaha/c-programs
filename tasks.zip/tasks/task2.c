#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int elem;
    struct Node *next;
} List;

void
on_screen(List *L) {
    List *cur = L;
    while (cur) {
        printf("%d -> ", cur->elem);
        cur = cur->next;
    }
}

void
delete_lis(List *L) {
    if (!L) {
        return;
    }
    delete_lis(L->next);
    free(L);
}

List *
delete_last(List *L) {
    List *cur = L;
    if (!L) {
        return NULL;
    }
    if (L->next == NULL){
        free(L);
        return NULL;
    }
    L->next = delete_last(L->next);
    return L;
}

List *
add_to_list(List *L, int i) {
    List *cur, *ptr;
    ptr = L;
    cur = calloc(1, sizeof(List));
    cur->elem = i;
    cur->next = NULL;
    if (!L) {
        return cur;
    }
    while (L->next) {
        L = L->next;
    }
    L->next = cur;
    return ptr;
}

int
main(int argc, char *argv[]) {
    List *L = NULL;
// check argc
    FILE *fp;
    fp = fopen (argv[1], "r");
    int i;
    while (fscanf(fp, "%d", &i) == 1) {
        printf("%d\n", i);
        L = add_to_list(L, i);
    }
    putchar('\n');
    on_screen(L);
    putchar('\n');
    L = delete_last(L);
    on_screen(L);
    delete_lis(L);
    fclose(fp);
    return 0;
}
