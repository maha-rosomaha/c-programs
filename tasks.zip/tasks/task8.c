#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Node {
    int elem;
    struct Node *next;
} list;

list *
creating(void) {
    list *cur = NULL, *start = NULL, *last = NULL;
    int n;
    while (scanf("%d", &n) == 1) {
        cur = calloc(1, sizeof(list));
        cur->next = NULL;
        cur->elem = n;
        if (!start) {
            start = cur;
            last = cur;
        }
        else {
            last->next = cur;
            last = last->next;
        }
    }
    return start;
}

int
check(list *lis, int elem) {
    int n = 0;
    list *cur = lis;
    while (cur) {
        if (elem == cur->elem) {
            n++;
        }
        cur = cur->next;
    }
    return n;
}

list *
find_delete(list *lis, int elem) {
    list *cur = lis, *tmp = NULL;
    while (lis) {
        if (lis) {
            if (elem == lis->elem) {
                tmp = 



list *
delete_repeats(list *lis) {
    list *tmp = NULL, *cur = lis;
    int elem;
    while (lis) {
        elem = lis->elem;
        tmp = lis->next;
        lis->next = find_delete(tmp, elem);
        lis = lis->next;
    }
    return cur;
}



void
on_screen(list *lis) {
    while (lis) {
        printf("%d|=>", lis->elem);
        lis = lis->next;
    }
}

void
delete_mem(list *lis) {
    list *cur = NULL;
    while (lis) {
        cur = lis;
        lis = lis->next;
        free(cur);
    }
}

int
main(void) {
    list *lis1;
    lis1 = creating();
    on_screen(lis1);
    putchar('\n');
    
    delete_mem(lis1);
    return 0;
}
