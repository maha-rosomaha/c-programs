#include <stdio.h>
#include <string.h>

#define N 3
#define M 3

void
fill(int (*A)[M], int n) {
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < M; j++) {
            scanf("%d", &A[i][j]);
        }
    }
}

void
find(int *Mas, int k, int *min, int *max, int *mini, int *maxi) {
    int loc_min, loc_max, loc_mini = 0, loc_maxi = 0, i;
    loc_min = Mas[0];
    loc_max = Mas[0];
    for (i = 1; i < k; i++) {
        if (Mas[i] > loc_max) {
            loc_max = Mas[i];
            loc_maxi = i;
        }
        if (Mas[i] < loc_min) {
            loc_min = Mas[i];
            loc_mini = i;
        }
    }
    *min = loc_min;
    *max = loc_max;
    *mini = loc_mini;
    *maxi = loc_maxi;
}

int
check_max(int (*A)[M], int n, int maxi, int max) {
    int j;
    for (j = 0; j < N; j++) {
        if (max > A[j][maxi]) {
            return 0;
        }
    }
    return 1;
}

int
check_min(int (*A)[M], int n, int mini, int min) {
    int j;
    for (j = 0; j < N; j++) {
        if (min < A[j][mini]) {
            return 0;
        }
    }
    return 1;
}

void
print_numbers(int (*A)[M], int n) {
    int i, j, k, min, max, maxi, mini;
    for (i = 0; i < n; i++) {
        find(A[i], M,  &min, &max, &mini, &maxi);
        if (check_max(A, N, maxi, max)) {
            printf("MAX ON %d and %d IS : %d\n", i, maxi, max);
        }
        if (check_min(A, N, mini, min)) {
            printf("MIN ON %d and %d IS : %d\n", i, mini, min);
        }
    }
}

int
main(void) {
    int Mat[N][M];
    fill(Mat, N);
    print_numbers(Mat, N);
    return 0;
}
