#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>


int
main(int argc, char *argv[]) {
    FILE *fp;
    int c, sharp = 0, local_beg = 0, beg_pos = 0, flag = 0, new_beg = 0;
    fp = fopen(argv[argc-1], "r+");
    while ((c = fgetc(fp)) != EOF) {
        if (c == '#') {
            sharp = 1;
        }
        if (c != '\n') {
            while ((c = fgetc(fp)) != '\n') {
                if (c == EOF) {
                    if (sharp) {
                        beg_pos = local_beg;
                    }
                    flag = 1;
                    break;
                }
            }
        }
        if (flag) {
            break;
        }
        if (sharp) {
            beg_pos = local_beg;
        }
        local_beg = ftell(fp);
        sharp = 0;
    }
    fseek(fp, beg_pos, SEEK_SET);
    if (sharp) {
        fclose(fp);
        truncate(argv[1], beg_pos);
        return 0;
    }
    while ((c = fgetc(fp)) != '\n');
    new_beg = ftell(fp);
    while ((c = fgetc(fp)) != EOF) {
        new_beg = ftell(fp);
        fseek(fp, beg_pos, SEEK_SET);
        fputc(c, fp);
        fseek(fp, new_beg, SEEK_SET);
    }
    fclose(fp);
    return 0;
}
