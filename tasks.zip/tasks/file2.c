#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void
concat(FILE *fp, FILE *tf) {
    char buf[4];
    fseek(tf, 0, SEEK_SET);
    fseek(fp, 0, SEEK_END);
    while (fgets(buf, 4, tf)) {
        fputs(buf, fp);
    }
}

int
main(int argc, char *argv[]) {
    FILE *fp, *tf;
    int i;
    fp = fopen(argv[1], "w");
    for (i = 2; i < argc; i++) {
        tf = fopen(argv[i], "r");
        concat(fp, tf);
        fclose(tf);
    }
    fclose(fp);
    return 0;
}
