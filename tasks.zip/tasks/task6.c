#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int elem;
    struct Node *next;
} List;

void
fill(int *A, int n) {
    int i;
    for (i = 0; i < n; i++) {
        scanf("%d", &A[i]);
    }
}

List *
add(List *lis, int n) {
    List *cur = NULL, *tmp = lis;
    int i;
    cur = calloc(1, sizeof(List));
    cur->elem = n;
    cur->next = NULL;
    if (!lis) {
        return cur;
    }
    while (lis->next) {
        lis = lis->next;
    }
    lis->next = cur;
    return tmp;
}


List *
create(int *A, int n) {
    int i;
    List *cur = NULL;
    for (i = 0; i < n; i++) {
        if (A[i] < 0) {
            cur = add(cur, A[i]);
        }
    }
    return cur;
}

void
on_screen(int *A, int n) {
    int i;
    for (i = 0; i < n; i++) {
        printf("%d||=>", A[i]);
    }
    putchar('\n');
}

void
on_scr_lis(List *lis) {
    List *cur = lis;
    int i;
    while(cur) {
        printf("%d||=>", cur->elem);
        cur = cur->next;
    }
}

void
delete_lis(List *lis) {
    List *cur = lis;
    if (cur) {
	delete_lis(cur->next);
        free(cur);
    }
}

int
main(void) {
    int *Mas, n;
    List *lis;
    printf("How much? ");
    scanf("%d", &n);
    Mas = calloc(n, sizeof(int));
    fill(Mas, n);
    on_screen(Mas, n);
    lis = create(Mas, n);
    on_scr_lis(lis);
    free(Mas);
    delete_lis(lis);
    return 0;
}
