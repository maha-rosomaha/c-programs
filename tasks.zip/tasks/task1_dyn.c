#include <stdio.h>
#include <stdlib.h>

int **
mem_cr(int n, int m) {
    int **A;
    int i;
    A = calloc(n, sizeof(int *));
    for (i = 0; i < n; i++) {
        A[i] = calloc(m, sizeof(int));
    }
    return A;
}

void
fill(int **A, int n, int m) {
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            scanf("%d", &A[i][j]);
        }
    }
}

void
find(int *Mas, int k, int *min, int *max, int *mini, int *maxi) {
    int loc_min, loc_max, loc_mini = 0, loc_maxi = 0, i;
    loc_min = Mas[0];
    loc_max = Mas[0];
    for (i = 1; i < k; i++) {
        if (Mas[i] > loc_max) {
            loc_max = Mas[i];
            loc_maxi = i;
        }
        if (Mas[i] < loc_min) {
            loc_min = Mas[i];
            loc_mini = i;
        }
    }
    *min = loc_min;
    *max = loc_max;
    *mini = loc_mini;
    *maxi = loc_maxi;
}

int
check_max(int **A, int n, int maxi, int max) {
    int j;
    for (j = 0; j < n; j++) {
        if (max > A[j][maxi]) {
            return 0;
        }
    }
    return 1;
}

int
check_min(int **A, int n, int mini, int min) {
    int j;
    for (j = 0; j < n; j++) {
        if (min < A[j][mini]) {
            return 0;
        }
    }
    return 1;
}

void
print_numbers(int **A, int n, int m) {
    int i, j, k, min, max, maxi, mini;
    for (i = 0; i < n; i++) {
        find(A[i], m,  &min, &max, &mini, &maxi);
        if (check_max(A, n, maxi, max)) {
            printf("MAX ON %d and %d IS : %d\n", i, maxi, max);
        }
        if (check_min(A, n, mini, min)) {
            printf("MIN ON %d and %d IS : %d\n", i, mini, min);
        }
    }
}

void
delete_mat(int **A, int N) {
    int i;
    for (i = 0; i < N; i++) {
        free(A[i]);
    }
    free(A);
}

int
main(void) {
    int **Mat;
    int N, M;
    scanf("%d%d", &N, &M);
    Mat = mem_cr(N, M);
    fill(Mat, N, M);
    print_numbers(Mat, N, M);
    delete_mat(Mat, N);
    return 0;
}

