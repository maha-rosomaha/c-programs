#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void
pech(FILE *fp) {
	int i = ftell(fp);
	printf("*****\n");
	printf("%d\n", i);
	printf("*****\n");
	fseek(fp, 3, SEEK_SET);
}

int
main(int argc, char *argv[]) {
    if (argc < 2) {
        perror("Error ");
        exit(1);
    }
    FILE *fp;
    int i, j, n, c, k = 0, l;
    fp = fopen(argv[argc - 1], "r");
    if (!fp) {
        perror("FOPEN");
        exit(1);
    }
    i = ftell(fp);
    printf("%d", i);
    putchar('\n');
    fseek(fp, 0, SEEK_END);
    j = ftell(fp);
    printf("%d", j);
    putchar('\n');
    n = j - i;
    printf("%d", n);
    putchar('\n');
    fseek(fp, 0, SEEK_SET);
    c = fgetc(fp);
    while (c != EOF) {
        if (c == '\n') {
            break;
        }
        putchar(c);
        k++;
        c = fgetc(fp);
    }
    putchar('\n');
    printf("%d", k);
    putchar('\n');
    l = ftell(fp);
    printf("%d", l);
    putchar('\n');
    fseek(fp, 6, SEEK_SET);
    pech(fp);
    i = ftell(fp);
    printf("%d\n", i);
    return 0;
}
