#ifndef Tests1_c
#define Tests1_c value

void
interface(void);
void
ask(void);

#endif
