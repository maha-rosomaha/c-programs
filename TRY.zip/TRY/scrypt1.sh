#!/bin/bash
echo "ALL FLAGS COMPILATION"
gcc MaOp1.c FuOp1.c Tests1.c -O2 -Wall -Werror -pedantic-errors -Wno-pointer-sign -Wextra -std=gnu11 -ftrapv -fsanitize=undefined
echo "ALL FLAGS COMPILATION SUCCEEDED"
echo "-g FLAG COMPILATION"
gcc -g -o val.out MaOp1.c FuOp1.c Tests1.c -Wall -Werror -pedantic-errors -Wno-pointer-sign -Wextra -std=gnu11 -ftrapv
echo "-g FLAG COMPILATION SUCCEEDED"
valgrind ./val.out
echo "--coverage FLAGS COMPILATION"
gcc --coverage -o covvy.out FuOp1.c Tests1.c MaOp1.c
echo "--coverage FLAGS COMPILATION SUCCEEDED"
./covvy.out
lcov --capture --directory ./ --rc lcov_branch_coverage=1 --output-file coverage.info
genhtml coverage.info --branch-coverage
